#include "Game.hpp"

/**
 * @brief 最小限の処理を記述するmain関数
 * ここはGameを呼ぶだけ
 * 
 * @param argc 
 * @param argv 
 * @return int 
 */
int main(int argc, char* argv[]){
    Game game;
    game.run();
    return 0;
}