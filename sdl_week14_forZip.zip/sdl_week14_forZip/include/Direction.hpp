#ifndef DIRECTION_H
#define DIRECTION_H

// キャラクタの向き
enum class Direction{
    Left, 
    Right
};

#endif  // DIRECTION_H