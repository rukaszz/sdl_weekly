#ifndef DRAWBOUNDS_H
#define DRAWBOUNDS_H

// 描画境界
struct DrawBounds{
    double drawableWidth;
    double drawableHeight;
};

#endif  // DRAWBOUNDS_H