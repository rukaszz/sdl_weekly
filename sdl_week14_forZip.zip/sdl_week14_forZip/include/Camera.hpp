#ifndef CAMERA_H
#define CAMERA_H

struct Camera{
    double x;
    double y;
    double width;
    double height;
};

#endif  // CAMERA_H